const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const Product = require("./models/Product");

const app = express();

const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// AngularJS Frontend
app.use(express.static(path.join(__dirname, "public")));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/productdb")

.then(() => {

    console.log("MongoDB Connected Successfully");

    app.listen(PORT, () => {
        console.log("Server running at http://localhost:3000");
    });

})

.catch((error) => {
    console.log("MongoDB Error:", error);
});


// GET - Fetch All Products

app.get("/api/products", async (req, res) => {

    try {

        const products = await Product.find()
            .select("name category price");

        res.status(200).json(products);

    }

    catch (error) {

        res.status(500).json({
            message: "Error fetching products",
            error: error.message
        });

    }

});


// POST - Add New Product

app.post("/api/products", async (req, res) => {

    try {

        const {
            productId,
            name,
            category,
            price,
            stockQuantity
        } = req.body;

        if (
            productId == null ||
            !name ||
            !category ||
            price == null ||
            stockQuantity == null
        ) {

            return res.status(400).json({
                message: "All fields are required"
            });

        }

        const existingProduct = await Product.findOne({
            productId: Number(productId)
        });

        if (existingProduct) {

            return res.status(409).json({
                message: "Product ID already exists"
            });

        }

        const product = new Product({

            productId: Number(productId),
            name: name,
            category: category,
            price: Number(price),
            stockQuantity: Number(stockQuantity)

        });

        const savedProduct = await product.save();

        res.status(201).json({

            message: "Product Added Successfully",
            product: savedProduct

        });

    }

    catch (error) {

        res.status(500).json({
            message: "Error adding product",
            error: error.message
        });

    }

});


// PUT - Update Product Price By Product ID

app.put("/api/products/:productId", async (req, res) => {

    try {

        const productId = Number(req.params.productId);

        const newPrice = Number(req.body.price);

        if (
            !Number.isFinite(productId) ||
            !Number.isFinite(newPrice) ||
            newPrice <= 0
        ) {

            return res.status(400).json({
                message: "Enter valid product ID and price"
            });

        }

        const updatedProduct = await Product.findOneAndUpdate(

            { productId: productId },

            { $set: { price: newPrice } },

            { new: true, runValidators: true }

        );

        if (!updatedProduct) {

            return res.status(404).json({
                message: "Product not found"
            });

        }

        res.status(200).json({

            message: "Product Price Updated Successfully",
            product: updatedProduct

        });

    }

    catch (error) {

        res.status(500).json({
            message: "Error updating product price",
            error: error.message
        });

    }

});