var app = angular.module("productApp", []);

app.controller("ProductController", function ($scope, $http) {

    $scope.product = {};

    $scope.update = {};

    $scope.products = [];


    // GET - Fetch All Products

    $scope.loadProducts = function () {

        $http.get("/api/products")

        .then(function (response) {

            $scope.products = response.data;

        })

        .catch(function (error) {

            console.log("GET ERROR:", error);

            alert("Error loading products");

        });

    };


    // POST - Add New Product

    $scope.addProduct = function () {

        var productData = {

            productId: Number($scope.product.productId),

            name: $scope.product.name,

            category: $scope.product.category,

            price: Number($scope.product.price),

            stockQuantity: Number($scope.product.stockQuantity)

        };


        $http.post("/api/products", productData)

        .then(function (response) {

            alert("Product Added Successfully!");

            $scope.resetProduct();

            $scope.loadProducts();

        })

        .catch(function (error) {

            console.log("POST ERROR:", error);

            alert(
                error.data && error.data.message
                ? error.data.message
                : "Error adding product"
            );

        });

    };


    // PUT - Update Product Price

   // PUT - Update Complete Product Details

$scope.updateProduct = function () {

    var productId = Number($scope.update.productId);

    var productData = {

        name: $scope.update.name,

        category: $scope.update.category,

        price: Number($scope.update.price),

        stockQuantity: Number($scope.update.stockQuantity)

    };

    $http.put(
        "/api/products/" + productId,
        productData
    )

    .then(function (response) {

        alert("Product Details Updated Successfully!");

        $scope.update = {};

        $scope.loadProducts();

    })

    .catch(function (error) {

        console.log("PUT ERROR:", error);

        alert(
            error.data && error.data.message
            ? error.data.message
            : "Error updating product"
        );

    });

};
    // Reset Product Form

    $scope.resetProduct = function () {

        $scope.product = {};

    };


    // Load Products On Page Open

    $scope.loadProducts();

});