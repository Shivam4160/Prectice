const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({

    productId: {
        type: Number,
        required: true,
        unique: true
    },

    name: {
        type: String,
        required: true
    },

    category: {
        type: String,
        required: true
    },

    price: {
        type: Number,
        required: true
    },

    stockQuantity: {
        type: Number,
        required: true
    }

});

module.exports = mongoose.model("Product", productSchema);