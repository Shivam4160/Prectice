var app = angular.module("employeeApp", []);

app.controller("EmployeeController", function ($scope, $http) {

    // Employee list
    $scope.employees = [];

    // Current employee
    $scope.employee = {};

    // Edit mode
    $scope.isEditing = false;

    $scope.loadEmployees = function () {

        $http.get("/api/employees")

            .then(function (response) {

                $scope.employees = response.data;

            })

            .catch(function (error) {

                console.error(error);

                alert("Error loading employees");

            });

    };

    $scope.saveEmployee = function () {

        // UPDATE
        if ($scope.isEditing) {

            $http.put(
                "/api/employees/" +
                $scope.employee.employeeId,
                $scope.employee
            )

            .then(function (response) {

                alert("Employee updated successfully");

                $scope.resetForm();

                $scope.loadEmployees();

            })

            .catch(function (error) {

                console.error(error);

                alert(
                    error.data &&
                    error.data.message
                        ? error.data.message
                        : "Error updating employee"
                );

            });

        }

        // ADD
        else {

            $http.post(
                "/api/employees",
                $scope.employee
            )

            .then(function (response) {

                alert("Employee added successfully");

                $scope.resetForm();

                $scope.loadEmployees();

            })

            .catch(function (error) {

                console.error(error);

                alert(
                    error.data &&
                    error.data.message
                        ? error.data.message
                        : "Error adding employee"
                );

            });

        }

    };


    $scope.deleteEmployee = function (employeeId) {

        var confirmDelete =
            confirm(
                "Are you sure you want to delete employee " +
                employeeId +
                "?"
            );

        if (!confirmDelete) {
            return;
        }

        $http.delete(
            "/api/employees/" + employeeId
        )

        .then(function (response) {

            alert("Employee deleted successfully");

            $scope.loadEmployees();

        })

        .catch(function (error) {

            console.error(error);

            alert(
                error.data &&
                error.data.message
                    ? error.data.message
                    : "Error deleting employee"
            );

        });

    };

    $scope.resetForm = function () {

        $scope.employee = {};

        $scope.isEditing = false;

    };
    
    $scope.loadEmployees();

});