const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const Employee = require("./models/Employee");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve AngularJS frontend
app.use(express.static(path.join(__dirname, "public")));

// MongoDB connection
mongoose
  .connect("mongodb://127.0.0.1:27017/employeeDB")
  .then(() => {
    console.log("MongoDB connected successfully");
  })
  .catch((error) => {
    console.error("MongoDB connection error:", error);
  });

// GET - Retrieve all employees

app.get("/api/employees", async (req, res) => {
  try {
    const employees = await Employee.find().sort({ employeeId: 1 });

    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({
      message: "Error retrieving employees",
      error: error.message
    });
  }
});

// GET - Retrieve one employee

app.get("/api/employees/:employeeId", async (req, res) => {
  try {
    const employee = await Employee.findOne({
      employeeId: req.params.employeeId
    });

    if (!employee) {
      return res.status(404).json({
        message: "Employee not found"
      });
    }
    res.status(200).json(employee);
    
  } catch (error) {
    res.status(500).json({
      message: "Error retrieving employee",
      error: error.message
    });
  }
});

// DELETE - Delete employee

app.delete("/api/employees/:employeeId", async (req, res) => {
  try {
    const employee = await Employee.findOneAndDelete({
      employeeId: req.params.employeeId
    });

    if (!employee) {
      return res.status(404).json({
        message: "Employee not found"
      });
    }

    res.status(200).json({
      message: "Employee deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      message: "Error deleting employee",
      error: error.message
    });
  }
});


app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});