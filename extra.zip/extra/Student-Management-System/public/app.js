var app = angular.module("studentApp", []);

app.controller("StudentController", function ($scope, $http) {

    $scope.student = {};

    $scope.students = [];

    $scope.message = "";


    // GET - Fetch All Students

    $scope.loadStudents = function () {

    $http.get("/api/students")

    .then(function (response) {

        $scope.students = response.data;

    })

    .catch(function (error) {

        console.log(error);

    });

};


    // POST - Add New Student

    $scope.saveStudent = function () {

        var studentData = {

            studentId: Number($scope.student.studentId),

            name: $scope.student.name,

            age: Number($scope.student.age),

            course: $scope.student.course,

            admissionDate: $scope.student.admissionDate

        };


        $http.post("/api/students", studentData)

        .then(function (response) {

            alert("Student Added Successfully!");

            $scope.message = response.data.message;

            $scope.resetForm();

            $scope.loadStudents();

        })

        .catch(function (error) {

            console.log("POST ERROR:", error);

            $scope.message =
                error.data && error.data.message
                ? error.data.message
                : "Error adding student";

            alert($scope.message);

        });

    };


    // Reset Form

    $scope.resetForm = function () {

        $scope.student = {};

    };


    // Load Students On Page Open

    $scope.loadStudents();

});