const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const Student = require("./models/Student");

const app = express();

const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// AngularJS frontend
app.use(express.static(path.join(__dirname, "public")));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/studentdb")

.then(() => {

    console.log("MongoDB Connected Successfully");

    app.listen(PORT, () => {
        console.log("Server running at http://localhost:3000");
    });

})

.catch((error) => {
    console.log("MongoDB Connection Error:", error);
});


// GET API - Fetch All Students
app.get("/api/students", async (req, res) => {

    try {

        const students = await Student.find()
            .select("studentId name age course admissionDate");

        res.status(200).json(students);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


// POST API - Add New Student
app.post("/api/students", async (req, res) => {

    try {

        const {
            studentId,
            name,
            age,
            course,
            admissionDate
        } = req.body;

        // Validation
        if (
            studentId == null ||
            !name ||
            age == null ||
            !course ||
            !admissionDate
        ) {

            return res.status(400).json({
                message: "All fields are required"
            });

        }

        // Check duplicate ID
        const existingStudent = await Student.findOne({
            studentId: Number(studentId)
        });

        if (existingStudent) {

            return res.status(409).json({
                message: "Student ID already exists"
            });

        }

        // Create Student
        const student = new Student({

            studentId: Number(studentId),
            name: name,
            age: Number(age),
            course: course,
            admissionDate: new Date(admissionDate)

        });

        // Save Student
        const savedStudent = await student.save();

        res.status(201).json({

            message: "Student Added Successfully",

            student: savedStudent

        });

    }

    catch (error) {

        console.log("POST ERROR:", error);

        res.status(500).json({

            message: "Error adding student",
            error: error.message

        });

    }

});