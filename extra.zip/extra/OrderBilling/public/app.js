var app = angular.module("orderApp", []);

app.controller("OrderController", function ($scope, $http) {

    $scope.newOrder = {};
    $scope.updateOrderData = {};

    // GET - Fetch All Orders
    $scope.getOrders = function () {
        $http.get("/api/orders")
        .then(function (response) {
            $scope.orders = response.data;
        })
        .catch(function (error) {
            alert("Error Fetching Orders");
        });
    };

    // POST - Create New Order
    $scope.addOrder = function () {

        $http.post("/api/orders", $scope.newOrder)
        .then(function (response) {
            alert("Order Created Successfully");

            $scope.newOrder = {};

            $scope.getOrders();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Creating Order");
        });
    };

    // PUT - Update Order Status
    $scope.updateOrder = function () {

        var id = $scope.updateOrderData.orderId;

        var data = {
            status: $scope.updateOrderData.status
        };

        $http.put("/api/orders/" + id, data)
        .then(function (response) {
            alert("Order Status Updated Successfully");

            $scope.updateOrderData = {};

            $scope.getOrders();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Updating Order");
        });
    };

    // Load Orders
    $scope.getOrders();

});