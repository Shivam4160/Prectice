const express = require("express");
const mongoose = require("mongoose");
const Order = require("./models/Order");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/orderdb")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// GET - Retrieve All Orders
app.get("/api/orders", async (req, res) => {
    try {
        const orders = await Order.find()
            .select("customerName totalAmount status");

        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST - Create New Order
app.post("/api/orders", async (req, res) => {
    try {
        const order = new Order(req.body);
        await order.save();

        res.status(201).json({
            message: "Order Created Successfully",
            order: order
        });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PUT - Update Order Status
app.put("/api/orders/:orderId", async (req, res) => {
    try {
        const { status } = req.body;

        if (!["Pending", "Processing", "Delivered", "Cancelled"].includes(status)) {
            return res.status(400).json({
                message: "Enter a valid order status"
            });
        }

        const updatedOrder = await Order.findOneAndUpdate(
            { orderId: Number(req.params.orderId) },
            { $set: { status: status } },
            { new: true, runValidators: true }
        );

        if (!updatedOrder) {
            return res.status(404).json({
                message: "Order Not Found"
            });
        }

        res.json({
            message: "Order Status Updated Successfully",
            updatedOrder: updatedOrder
        });

    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Start Server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});