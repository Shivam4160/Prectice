const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
    orderId: {
        type: Number,
        required: true,
        unique: true
    },
    customerName: {
        type: String,
        required: true
    },
    orderDate: {
        type: Date,
        required: true
    },
    items: {
        type: String,
        required: true
    },
    totalAmount: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        required: true,
        enum: ["Pending", "Processing", "Delivered", "Cancelled"]
    }
});

module.exports = mongoose.model("Order", orderSchema);