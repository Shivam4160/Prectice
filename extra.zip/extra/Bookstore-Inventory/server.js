const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const Book = require("./models/Book");

const app = express();

const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// AngularJS Frontend
app.use(express.static(path.join(__dirname, "public")));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/bookdb")

.then(() => {

    console.log("MongoDB Connected Successfully");

    app.listen(PORT, () => {
        console.log("Server running at http://localhost:3000");
    });

})

.catch((error) => {
    console.log("MongoDB Error:", error);
});


// GET - Retrieve All Books

app.get("/api/books", async (req, res) => {

    try {

        const books = await Book.find()
            .select("title author price");

        res.status(200).json(books);

    }

    catch (error) {

        res.status(500).json({
            message: "Error fetching books",
            error: error.message
        });

    }

});


// POST - Add New Book

app.post("/api/books", async (req, res) => {

    try {

        const {
            bookId,
            title,
            author,
            price,
            publicationYear
        } = req.body;

        if (
            bookId == null ||
            !title ||
            !author ||
            price == null ||
            publicationYear == null
        ) {

            return res.status(400).json({
                message: "All fields are required"
            });

        }

        const existingBook = await Book.findOne({
            bookId: Number(bookId)
        });

        if (existingBook) {

            return res.status(409).json({
                message: "Book ID already exists"
            });

        }

        const book = new Book({

            bookId: Number(bookId),
            title: title,
            author: author,
            price: Number(price),
            publicationYear: Number(publicationYear)

        });

        const savedBook = await book.save();

        res.status(201).json({

            message: "Book Added Successfully",
            book: savedBook

        });

    }

    catch (error) {

        res.status(500).json({
            message: "Error adding book",
            error: error.message
        });

    }

});


// PUT - Update Book Price By Book ID

app.put("/api/books/:bookId", async (req, res) => {

    try {

        const bookId = Number(req.params.bookId);

        const newPrice = Number(req.body.price);

        if (
            !Number.isFinite(bookId) ||
            !Number.isFinite(newPrice) ||
            newPrice <= 0
        ) {

            return res.status(400).json({
                message: "Enter valid book ID and price"
            });

        }

        const updatedBook = await Book.findOneAndUpdate(

            { bookId: bookId },

            { $set: { price: newPrice } },

            { new: true, runValidators: true }

        );

        if (!updatedBook) {

            return res.status(404).json({
                message: "Book not found"
            });

        }

        res.status(200).json({

            message: "Book Price Updated Successfully",
            book: updatedBook

        });

    }

    catch (error) {

        res.status(500).json({
            message: "Error updating book price",
            error: error.message
        });

    }

});