var app = angular.module("bookApp", []);

app.controller("BookController", function ($scope, $http) {

    $scope.book = {};

    $scope.update = {};

    $scope.books = [];


    // GET - Retrieve All Books

    $scope.loadBooks = function () {

        $http.get("/api/books")

        .then(function (response) {

            $scope.books = response.data;

        })

        .catch(function (error) {

            console.log("GET ERROR:", error);

            alert("Error loading books");

        });

    };


    // POST - Add New Book

    $scope.addBook = function () {

        var bookData = {

            bookId: Number($scope.book.bookId),

            title: $scope.book.title,

            author: $scope.book.author,

            price: Number($scope.book.price),

            publicationYear: Number($scope.book.publicationYear)

        };


        $http.post("/api/books", bookData)

        .then(function (response) {

            alert("Book Added Successfully!");

            $scope.resetBook();

            $scope.loadBooks();

        })

        .catch(function (error) {

            console.log("POST ERROR:", error);

            alert(
                error.data && error.data.message
                ? error.data.message
                : "Error adding book"
            );

        });

    };


    // PUT - Update Book Price

    $scope.updatePrice = function () {

        var bookId = Number($scope.update.bookId);

        var price = Number($scope.update.price);

        $http.put(
            "/api/books/" + bookId,
            {
                price: price
            }
        )

        .then(function (response) {

            alert("Book Price Updated Successfully!");

            $scope.update = {};

            $scope.loadBooks();

        })

        .catch(function (error) {

            console.log("PUT ERROR:", error);

            alert(
                error.data && error.data.message
                ? error.data.message
                : "Error updating price"
            );

        });

    };


    // Reset Book Form

    $scope.resetBook = function () {

        $scope.book = {};

    };


    // Load Books On Page Open

    $scope.loadBooks();

});