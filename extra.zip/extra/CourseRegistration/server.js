const express = require("express");
const mongoose = require("mongoose");
const Course = require("./models/Course");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/coursedb")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// GET - List All Courses
app.get("/api/courses", async (req, res) => {
    try {
        const courses = await Course.find()
            .select("courseCode courseName credits");

        res.json(courses);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST - Add New Course
app.post("/api/courses", async (req, res) => {
    try {
        const course = new Course(req.body);
        await course.save();

        res.status(201).json({
            message: "Course Added Successfully",
            course: course
        });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PUT - Update Course Capacity or Credits
app.put("/api/courses/:courseId", async (req, res) => {
    try {
        const { capacity, credits } = req.body;
        const updateData = {};

        if (capacity !== undefined) {
            updateData.capacity = Number(capacity);
        }

        if (credits !== undefined) {
            updateData.credits = Number(credits);
        }

        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({
                message: "Enter capacity or credits to update"
            });
        }

        const updatedCourse = await Course.findOneAndUpdate(
            { courseId: Number(req.params.courseId) },
            { $set: updateData },
            { new: true, runValidators: true }
        );

        if (!updatedCourse) {
            return res.status(404).json({
                message: "Course Not Found"
            });
        }

        res.json({
            message: "Course Updated Successfully",
            updatedCourse: updatedCourse
        });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Start Server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});