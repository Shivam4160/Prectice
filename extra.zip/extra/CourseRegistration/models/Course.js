const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema({
    courseId: {
        type: Number,
        required: true,
        unique: true
    },
    courseCode: {
        type: String,
        required: true
    },
    courseName: {
        type: String,
        required: true
    },
    credits: {
        type: Number,
        required: true
    },
    capacity: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model("Course", courseSchema);