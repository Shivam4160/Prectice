var app = angular.module("courseApp", []);

app.controller("CourseController", function ($scope, $http) {

    $scope.newCourse = {};
    $scope.updateCourseData = {};

    // GET - Fetch All Courses
    $scope.getCourses = function () {
        $http.get("/api/courses")
        .then(function (response) {
            $scope.courses = response.data;
        })
        .catch(function (error) {
            alert("Error Fetching Courses");
        });
    };

    // POST - Add Course
    $scope.addCourse = function () {
        $http.post("/api/courses", $scope.newCourse)
        .then(function (response) {
            alert("Course Added Successfully");
            $scope.newCourse = {};
            $scope.getCourses();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Adding Course");
        });
    };

    // PUT - Update Course
    $scope.updateCourse = function () {

        var id = $scope.updateCourseData.courseId;

        var data = {};

        if ($scope.updateCourseData.credits !== undefined &&
            $scope.updateCourseData.credits !== null) {
            data.credits = Number($scope.updateCourseData.credits);
        }

        if ($scope.updateCourseData.capacity !== undefined &&
            $scope.updateCourseData.capacity !== null) {
            data.capacity = Number($scope.updateCourseData.capacity);
        }

        $http.put("/api/courses/" + id, data)
        .then(function (response) {
            alert("Course Updated Successfully");
            $scope.updateCourseData = {};
            $scope.getCourses();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Updating Course");
        });
    };

    // Load Courses
    $scope.getCourses();

});