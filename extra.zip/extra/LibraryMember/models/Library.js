const mongoose = require("mongoose");

const librarySchema = new mongoose.Schema({
    memberId: {
        type: Number,
        required: true,
        unique: true
    },
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    membershipType: {
        type: String,
        required: true
    },
    joinDate: {
        type: Date,
        required: true
    },
    outstandingFine: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model("Library", librarySchema);