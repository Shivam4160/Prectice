const express = require("express");
const mongoose = require("mongoose");
const Library = require("./models/Library");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/librarydb")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// GET - Retrieve All Members
app.get("/api/members", async (req, res) => {
    try {
        const members = await Library.find()
            .select("name membershipType email");

        res.json(members);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST - Add New Member
app.post("/api/members", async (req, res) => {
    try {
        const member = new Library(req.body);
        await member.save();

        res.status(201).json({
            message: "Member Added Successfully",
            member: member
        });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PUT - Update Membership Type
app.put("/api/members/:memberId", async (req, res) => {
    try {
        const { membershipType } = req.body;

        if (!membershipType) {
            return res.status(400).json({
                message: "Membership Type is Required"
            });
        }

        const updatedMember = await Library.findOneAndUpdate(
            { memberId: Number(req.params.memberId) },
            { $set: { membershipType: membershipType } },
            { new: true, runValidators: true }
        );

        if (!updatedMember) {
            return res.status(404).json({
                message: "Member Not Found"
            });
        }

        res.json({
            message: "Membership Type Updated Successfully",
            updatedMember: updatedMember
        });

    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Start Server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});