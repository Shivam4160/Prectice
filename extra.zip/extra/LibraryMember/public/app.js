var app = angular.module("libraryApp", []);

app.controller("LibraryController", function ($scope, $http) {

    $scope.newMember = {};
    $scope.updateMemberData = {};

    // GET - Fetch All Members
    $scope.getMembers = function () {
        $http.get("/api/members")
        .then(function (response) {
            $scope.members = response.data;
        })
        .catch(function (error) {
            alert("Error Fetching Members");
        });
    };

    // POST - Add New Member
    $scope.addMember = function () {

        $http.post("/api/members", $scope.newMember)
        .then(function (response) {
            alert("Member Added Successfully");

            $scope.newMember = {};

            $scope.getMembers();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Adding Member");
        });
    };

    // PUT - Update Membership Type
    $scope.updateMember = function () {

        var id = $scope.updateMemberData.memberId;

        var data = {
            membershipType: $scope.updateMemberData.membershipType
        };

        $http.put("/api/members/" + id, data)
        .then(function (response) {
            alert("Membership Type Updated Successfully");

            $scope.updateMemberData = {};

            $scope.getMembers();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Updating Membership");
        });
    };

    // Load Members
    $scope.getMembers();

});