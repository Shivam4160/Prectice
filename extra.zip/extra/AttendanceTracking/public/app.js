var app = angular.module("attendanceApp", []);

app.controller("AttendanceController", function ($scope, $http) {

    $scope.newAttendance = {};
    $scope.updateAttendanceData = {};

    // GET - Fetch Attendance Records
    $scope.getAttendance = function () {
        $http.get("/api/attendance")
        .then(function (response) {
            $scope.records = response.data;
        })
        .catch(function (error) {
            alert("Error Fetching Attendance Records");
        });
    };

    // POST - Mark Attendance
    $scope.markAttendance = function () {

        $http.post("/api/attendance", $scope.newAttendance)
        .then(function (response) {
            alert("Attendance Marked Successfully");

            $scope.newAttendance = {};

            $scope.getAttendance();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Marking Attendance");
        });
    };

    // PUT - Update Attendance Status
    $scope.updateAttendance = function () {

        var id = $scope.updateAttendanceData.attendanceId;

        var data = {
            status: $scope.updateAttendanceData.status
        };

        $http.put("/api/attendance/" + id, data)
        .then(function (response) {
            alert("Attendance Status Updated Successfully");

            $scope.updateAttendanceData = {};

            $scope.getAttendance();
        })
        .catch(function (error) {
            alert(error.data.message || "Error Updating Attendance");
        });
    };

    // Load Attendance Records
    $scope.getAttendance();

});
    