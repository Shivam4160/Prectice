const express = require("express");
const mongoose = require("mongoose");
const Attendance = require("./models/Attendance");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/attendancedb")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// GET - View Attendance Records
app.get("/api/attendance", async (req, res) => {
    try {
        const records = await Attendance.find()
            .select("studentId date status");

        res.json(records);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST - Mark Attendance
app.post("/api/attendance", async (req, res) => {
    try {
        const attendance = new Attendance(req.body);
        await attendance.save();

        res.status(201).json({
            message: "Attendance Marked Successfully",
            attendance: attendance
        });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PUT - Update Attendance Status
app.put("/api/attendance/:attendanceId", async (req, res) => {
    try {
        const { status } = req.body;

        if (!["Present", "Absent", "Late"].includes(status)) {
            return res.status(400).json({
                message: "Enter a valid attendance status"
            });
        }

        const updatedAttendance = await Attendance.findOneAndUpdate(
            { attendanceId: Number(req.params.attendanceId) },
            { $set: { status: status } },
            { new: true, runValidators: true }
        );

        if (!updatedAttendance) {
            return res.status(404).json({
                message: "Attendance Record Not Found"
            });
        }

        res.json({
            message: "Attendance Status Updated Successfully",
            updatedAttendance: updatedAttendance
        });

    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Start Server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});