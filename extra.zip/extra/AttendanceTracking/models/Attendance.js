const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
    attendanceId: {
        type: Number,
        required: true,
        unique: true
    },
    studentId: {
        type: Number,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        required: true,
        enum: ["Present", "Absent", "Late"]
    },
    remarks: {
        type: String,
        default: ""
    }
});

module.exports = mongoose.model("Attendance", attendanceSchema);