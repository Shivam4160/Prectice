var app = angular.module("ticketApp", []);

app.controller("TicketController", function($scope, $http) {

    $scope.tickets = [];

    $scope.newTicket = {};
    $scope.updateData = {};

    // GET - View Tickets
    $scope.getTickets = function() {
        $http.get("/api/tickets")
        .then(function(response) {
            $scope.tickets = response.data;
        });
    };

    // POST - Add Ticket
    $scope.addTicket = function() {

        $http.post("/api/tickets", $scope.newTicket)
        .then(function(response) {
            alert("Ticket Added Successfully");

            $scope.newTicket = {};
            $scope.getTickets();
        })
        .catch(function(error) {
            alert(error.data.message || "Error adding ticket");
        });
    };

    // PUT - Update Ticket Status
    $scope.updateTicket = function() {

        var id = $scope.updateData.ticketId;

        $http.put("/api/tickets/" + id, {
            status: $scope.updateData.status
        })
        .then(function(response) {
            alert("Ticket Status Updated Successfully");

            $scope.updateData = {};
            $scope.getTickets();
        })
        .catch(function(error) {
            alert(error.data.message || "Error updating ticket");
        });
    };

    // Load Tickets Initially
    $scope.getTickets();

});