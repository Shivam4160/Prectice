const express = require("express");
const mongoose = require("mongoose");
const Ticket = require("./models/Ticket");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/supportdb")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// GET - View All Tickets
app.get("/api/tickets", async (req, res) => {
    try {
        const tickets = await Ticket.find()
            .select("title description priority status");

        res.json(tickets);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST - Create New Ticket
app.post("/api/tickets", async (req, res) => {
    try {
        const ticket = new Ticket(req.body);
        const savedTicket = await ticket.save();

        res.status(201).json(savedTicket);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PUT - Update Ticket Status
app.put("/api/tickets/:ticketId", async (req, res) => {
    try {
        const { status } = req.body;

        if (!["Open", "In Progress", "Closed"].includes(status)) {
            return res.status(400).json({
                message: "Invalid ticket status"
            });
        }

        const updatedTicket = await Ticket.findOneAndUpdate(
            { ticketId: Number(req.params.ticketId) },
            { $set: { status: status } },
            { new: true, runValidators: true }
        );

        if (!updatedTicket) {
            return res.status(404).json({
                message: "Ticket not found"
            });
        }

        res.json(updatedTicket);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Start Server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});