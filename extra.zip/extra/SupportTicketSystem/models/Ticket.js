const mongoose = require("mongoose");

const ticketSchema = new mongoose.Schema({
    ticketId: {
        type: Number,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    priority: {
        type: String,
        enum: ["Low", "Medium", "High"],
        required: true
    },
    status: {
        type: String,
        enum: ["Open", "In Progress", "Closed"],
        default: "Open"
    },
    createdDate: {
        type: Date,
        required: true
    }
});

module.exports = mongoose.model("Ticket", ticketSchema);