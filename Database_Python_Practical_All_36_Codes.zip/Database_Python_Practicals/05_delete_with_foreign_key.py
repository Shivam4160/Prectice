import sqlite3

conn = sqlite3.connect("university_assignment.db")
cur = conn.cursor()
cur.execute("PRAGMA foreign_keys = ON")

# Delete an enrollment first because it refers to a student.
cur.execute("""DELETE FROM enrollments
WHERE student_id=(SELECT student_id FROM students
WHERE email='priya@example.com')""")
cur.execute("DELETE FROM students WHERE email='priya@example.com'")

conn.commit()
print("Dependent enrollment and student record deleted.")
conn.close()
