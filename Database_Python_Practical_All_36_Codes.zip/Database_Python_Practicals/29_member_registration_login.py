import tkinter as tk
from tkinter import messagebox
import sqlite3
import hashlib

conn = sqlite3.connect("members.db")
conn.execute("""CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE,
    username TEXT UNIQUE, password_hash TEXT)""")
conn.commit()
conn.close()

def register():
    name = name_entry.get().strip()
    email = email_entry.get().strip()
    username = user_entry.get().strip()
    password = pass_entry.get()
    if not name or not email or not username or not password:
        messagebox.showwarning("Missing", "Fill all fields.")
        return
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    try:
        conn = sqlite3.connect("members.db")
        conn.execute("INSERT INTO members(name,email,username,password_hash) VALUES(?,?,?,?)",
                     (name, email, username, password_hash))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Member registered.")
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Email or username already exists.")

root = tk.Tk()
root.title("Member Registration")
root.geometry("380x330")
root.configure(bg="#eef3f8")
tk.Label(root, text="Member Registration", font=("Arial", 18, "bold"),
         bg="#eef3f8").pack(pady=12)
entries = []
for label in ["Full Name", "Email", "Username", "Password"]:
    tk.Label(root, text=label, bg="#eef3f8").pack()
    e = tk.Entry(root, width=35, show="*" if label == "Password" else "")
    e.pack(pady=4)
    entries.append(e)
name_entry, email_entry, user_entry, pass_entry = entries
tk.Button(root, text="Register", command=register, width=18).pack(pady=15)
root.mainloop()
