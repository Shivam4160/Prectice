import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()

cur.execute("INSERT INTO products(name, quantity, price) VALUES (?, ?, ?)",
            ("Committed Item", 10, 25))
conn.commit()
print("First insert saved using commit().")

cur.execute("INSERT INTO products(name, quantity, price) VALUES (?, ?, ?)",
            ("Temporary Item", 5, 99))
conn.rollback()
print("Second insert cancelled using rollback().")

cur.execute("SELECT * FROM products WHERE name='Temporary Item'")
print("Temporary item found?", cur.fetchone() is not None)
conn.close()
