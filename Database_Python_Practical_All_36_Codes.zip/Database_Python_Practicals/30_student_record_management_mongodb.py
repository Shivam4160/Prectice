import tkinter as tk
from tkinter import messagebox
from pymongo import MongoClient
from pymongo.errors import PyMongoError

try:
    client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=3000)
    client.admin.command("ping")
    collection = client["practical_db"]["student_records"]
except Exception as error:
    client = None
    collection = None
    print("MongoDB connection failed:", error)

FIELDS = ['roll_no', 'name', 'subject1', 'subject2', 'subject3', 'total', 'percentage', 'grade']
LABELS = ['Roll No', 'Name', 'Subject 1 Marks', 'Subject 2 Marks', 'Subject 3 Marks', 'Total', 'Percentage', 'Grade']

def calculate_fields():
    try:
        m1 = float(entries["subject1"].get())
        m2 = float(entries["subject2"].get())
        m3 = float(entries["subject3"].get())
        total = m1 + m2 + m3
        percentage = total / 300 * 100
        if percentage >= 80:
            grade = "A"
        elif percentage >= 60:
            grade = "B"
        elif percentage >= 40:
            grade = "C"
        else:
            grade = "Fail"
        entries["total"].delete(0, tk.END)
        entries["total"].insert(0, str(total))
        entries["percentage"].delete(0, tk.END)
        entries["percentage"].insert(0, str(round(percentage, 2)))
        entries["grade"].delete(0, tk.END)
        entries["grade"].insert(0, grade)
    except ValueError:
        messagebox.showerror("Input Error", "Enter numbers for all three subject marks.")

def values_from_form():
    return {name: entries[name].get().strip() for name in FIELDS}

def clear_form():
    id_entry.delete(0, tk.END)
    for entry in entries.values():
        entry.delete(0, tk.END)
    result_box.delete("1.0", tk.END)

def insert_record():
    if collection is None:
        messagebox.showerror("MongoDB", "Start MongoDB service first.")
        return
    data = values_from_form()
    if not all(data.values()):
        messagebox.showwarning("Required", "Fill all fields.")
        return
    try:
        collection.insert_one(data)
        messagebox.showinfo("Saved", "Record inserted.")
        display_records()
    except PyMongoError as error:
        messagebox.showerror("Error", str(error))

def search_record():
    if collection is None:
        return
    key = id_entry.get().strip()
    if not key:
        messagebox.showwarning("Search", "Enter the ID shown in the list.")
        return
    try:
        from bson.objectid import ObjectId
        record = collection.find_one({"_id": ObjectId(key)})
        if record:
            for name in FIELDS:
                entries[name].delete(0, tk.END)
                entries[name].insert(0, str(record.get(name, "")))
            messagebox.showinfo("Found", "Record loaded.")
        else:
            messagebox.showinfo("Not found", "Record not found.")
    except Exception:
        messagebox.showerror("Error", "Enter a valid MongoDB ID.")

def update_record():
    if collection is None:
        return
    key = id_entry.get().strip()
    if not key:
        messagebox.showwarning("Update", "Enter MongoDB ID first.")
        return
    try:
        from bson.objectid import ObjectId
        result = collection.update_one({"_id": ObjectId(key)}, {"$set": values_from_form()})
        messagebox.showinfo("Update", "Modified records: " + str(result.modified_count))
        display_records()
    except Exception as error:
        messagebox.showerror("Error", str(error))

def delete_record():
    if collection is None:
        return
    key = id_entry.get().strip()
    if not key:
        messagebox.showwarning("Delete", "Enter MongoDB ID first.")
        return
    try:
        from bson.objectid import ObjectId
        result = collection.delete_one({"_id": ObjectId(key)})
        messagebox.showinfo("Delete", "Deleted records: " + str(result.deleted_count))
        display_records()
    except Exception as error:
        messagebox.showerror("Error", str(error))

def display_records():
    result_box.delete("1.0", tk.END)
    if collection is None:
        result_box.insert(tk.END, "MongoDB is not connected. Start local MongoDB.")
        return
    for record in collection.find().limit(100):
        result_box.insert(tk.END, str(record) + "\\n")

root = tk.Tk()
root.title("Student Record Management")
root.geometry("760x650")
root.configure(bg="#eef3f8")
tk.Label(root, text="Student Record Management", font=("Arial", 18, "bold"),
         bg="#eef3f8").pack(pady=10)
form = tk.Frame(root, bg="#eef3f8")
form.pack()
tk.Label(form, text="MongoDB ID", bg="#eef3f8").grid(row=0, column=0, sticky="w", pady=4)
id_entry = tk.Entry(form, width=35)
id_entry.grid(row=0, column=1, pady=4)
entries = {}
for i, name in enumerate(FIELDS):
    tk.Label(form, text=LABELS[i], bg="#eef3f8").grid(row=i+1, column=0, sticky="w", pady=4)
    entries[name] = tk.Entry(form, width=35)
    entries[name].grid(row=i+1, column=1, pady=4)
buttons = tk.Frame(root, bg="#eef3f8")
buttons.pack(pady=10)
for label, command in [("Calculate", calculate_fields), ("Insert", insert_record), ("Search", search_record),
                       ("Update", update_record), ("Delete", delete_record),
                       ("Display", display_records), ("Clear", clear_form)]:
    tk.Button(buttons, text=label, width=11, command=command).pack(side=tk.LEFT, padx=3)
tk.Label(root, text="Records (copy _id from here for Search / Update / Delete)",
         bg="#eef3f8").pack()
result_box = tk.Text(root, height=17, width=95)
result_box.pack(padx=10, pady=8)
display_records()
root.mainloop()
