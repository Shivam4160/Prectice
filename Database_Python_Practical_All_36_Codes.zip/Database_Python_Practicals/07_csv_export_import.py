import sqlite3
import csv

conn = sqlite3.connect("university_assignment.db")
cur = conn.cursor()

# Export enrollment details to CSV
cur.execute("""SELECT students.name, courses.course_name, enrollments.grade
FROM enrollments
JOIN students ON enrollments.student_id=students.student_id
JOIN courses ON enrollments.course_id=courses.course_id""")
rows = cur.fetchall()

with open("enrollments_export.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Student", "Course", "Grade"])
    writer.writerows(rows)
print("Enrollment data exported.")

# Create a sample CSV file if it does not exist.
with open("new_students.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["name", "age", "major", "email"])
    writer.writerow(["Kiran Shah", 21, "IT", "kiran@example.com"])
    writer.writerow(["Meera Desai", 20, "Computer Science", "meera@example.com"])

with open("new_students.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        cur.execute("""INSERT OR IGNORE INTO students(name, age, major, email)
        VALUES (?, ?, ?, ?)""",
        (row["name"], int(row["age"]), row["major"], row["email"]))

conn.commit()
print("New student records imported from CSV.")
conn.close()
