from pymongo import MongoClient
from pymongo.errors import PyMongoError

client = MongoClient("mongodb://localhost:27017/")
db = client["university_db"]
students = db["students_data"]

try:
    students.delete_many({})
    one_student = {
        "roll_no": 101, "name": "Amit Sharma", "email": "amit@example.com",
        "major": "Physics", "enrollments": [
            {"course": "Physics", "marks": 88},
            {"course": "Maths", "marks": 91}
        ]
    }
    result = students.insert_one(one_student)
    print("One student inserted:", result.inserted_id)

    many_students = [
        {"roll_no": 102, "name": "Priya Patel", "email": "priya@example.com",
         "major": "Computer Science", "enrollments": [{"course": "Python", "marks": 85}]},
        {"roll_no": 103, "name": "Rahul Verma", "email": "rahul@example.com",
         "major": "Physics", "enrollments": [{"course": "Physics", "marks": "Pending"}]},
        {"roll_no": 104, "name": "Sneha Joshi", "email": "sneha@example.com",
         "major": "Chemistry", "enrollments": [{"course": "Chemistry", "marks": 79}]},
        {"roll_no": 105, "name": "Kiran Shah", "email": "kiran@example.com",
         "major": "Physics", "enrollments": [{"course": "Physics", "marks": 92}]},
        {"roll_no": 106, "name": "Meera Desai", "email": "meera@example.com",
         "major": "Mathematics", "enrollments": [{"course": "Maths", "marks": "Pending"}]},
        {"roll_no": 107, "name": "Jay Patel", "email": "jay@example.com",
         "major": "Computer Science", "enrollments": [{"course": "Python", "marks": 81}]}
    ]
    result = students.insert_many(many_students)
    print("Multiple students inserted:", len(result.inserted_ids))
except PyMongoError as error:
    print("MongoDB operation error:", error)
finally:
    client.close()
