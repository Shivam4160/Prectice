import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()

print("All products:")
for row in cur.execute("SELECT * FROM products"):
    print(row)

cur.execute("SELECT * FROM products WHERE name=?", ("Pen",))
print("Product by name:", cur.fetchone())

print("Products with quantity below 60:")
for row in cur.execute("SELECT * FROM products WHERE quantity < 60"):
    print(row)

conn.close()
