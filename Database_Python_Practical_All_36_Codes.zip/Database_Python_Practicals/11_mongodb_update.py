from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
students = client["university_db"]["students_data"]

result = students.update_one({"roll_no": 101},
                             {"$set": {"name": "Amit Kumar"}})
print("Student updated:", result.modified_count)

# Add an enrollment
students.update_one({"roll_no": 101},
                    {"$push": {"enrollments": {"course": "Chemistry", "marks": 76}}})

# Update marks inside an enrollment
students.update_one(
    {"roll_no": 101, "enrollments.course": "Physics"},
    {"$set": {"enrollments.$.marks": 90}}
)

# Remove one enrollment
students.update_one({"roll_no": 101},
                    {"$pull": {"enrollments": {"course": "Chemistry"}}})

# Upsert: insert if roll number does not exist
result = students.update_one(
    {"roll_no": 108},
    {"$set": {"name": "New Student", "email": "new@example.com",
              "major": "Physics", "enrollments": []}},
    upsert=True
)
print("Upserted ID:", result.upserted_id)
client.close()
