from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
students = client["university_db"]["students_data"]

print("\nAll students")
for item in students.find():
    print(item)

print("\nPhysics students")
for item in students.find({"major": "Physics"}):
    print(item)

print("\nSorted by name")
for item in students.find().sort("name", 1):
    print(item["name"])

print("\nPagination: first 3 students")
for item in students.find().skip(0).limit(3):
    print(item["name"])

print("\nAverage numeric marks by major")
pipeline = [
    {"$unwind": "$enrollments"},
    {"$match": {"enrollments.marks": {"$type": "number"}}},
    {"$group": {"_id": "$major", "average_marks": {"$avg": "$enrollments.marks"}}}
]
for item in students.aggregate(pipeline):
    print(item)

client.close()
