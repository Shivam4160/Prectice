import sqlite3

conn = sqlite3.connect("university_assignment.db")
cur = conn.cursor()
cur.execute("PRAGMA foreign_keys = ON")

cur.execute("""CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, age INTEGER, major TEXT, email TEXT UNIQUE
)""")
cur.execute("""CREATE TABLE IF NOT EXISTS courses (
    course_id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT UNIQUE, course_name TEXT, credits INTEGER
)""")
cur.execute("""CREATE TABLE IF NOT EXISTS enrollments (
    enrollment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER, course_id INTEGER, grade TEXT,
    FOREIGN KEY(student_id) REFERENCES students(student_id),
    FOREIGN KEY(course_id) REFERENCES courses(course_id)
)""")
conn.commit()
print("University database and all 3 tables created.")
conn.close()
