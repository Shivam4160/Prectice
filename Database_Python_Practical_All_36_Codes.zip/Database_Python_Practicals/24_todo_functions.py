import sqlite3

def add_task(title, description):
    conn = sqlite3.connect("todo_list.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO tasks(title, description) VALUES (?, ?)",
                (title, description))
    conn.commit()
    conn.close()
    print("Task added.")

def view_tasks():
    conn = sqlite3.connect("todo_list.db")
    cur = conn.cursor()
    for row in cur.execute("SELECT * FROM tasks"):
        print(row)
    conn.close()

def complete_task(task_id):
    conn = sqlite3.connect("todo_list.db")
    cur = conn.cursor()
    cur.execute("UPDATE tasks SET completed=1 WHERE id=?", (task_id,))
    conn.commit()
    print("Rows updated:", cur.rowcount)
    conn.close()

def delete_task(task_id):
    conn = sqlite3.connect("todo_list.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=?", (task_id,))
    conn.commit()
    print("Rows deleted:", cur.rowcount)
    conn.close()

if __name__ == "__main__":
    add_task("Study Python", "Practice database programs")
    view_tasks()
