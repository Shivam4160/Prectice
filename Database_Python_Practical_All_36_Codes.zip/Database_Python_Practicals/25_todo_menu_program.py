import sqlite3

def connect():
    return sqlite3.connect("todo_list.db")

def add_task():
    title = input("Task title: ")
    description = input("Description: ")
    conn = connect()
    conn.execute("INSERT INTO tasks(title, description) VALUES (?, ?)",
                 (title, description))
    conn.commit()
    conn.close()
    print("Task added.")

def view_tasks():
    conn = connect()
    rows = conn.execute("SELECT * FROM tasks").fetchall()
    for row in rows:
        status = "Completed" if row[3] == 1 else "Pending"
        print(row[0], row[1], row[2], status)
    conn.close()

def complete_task():
    task_id = input("Task ID: ")
    conn = connect()
    conn.execute("UPDATE tasks SET completed=1 WHERE id=?", (task_id,))
    conn.commit()
    conn.close()
    print("Task marked completed.")

def delete_task():
    task_id = input("Task ID: ")
    conn = connect()
    conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()
    print("Task deleted.")

conn = connect()
conn.execute("""CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
    description TEXT, completed INTEGER DEFAULT 0)""")
conn.commit()
conn.close()

while True:
    print("\n1 Add  2 View  3 Complete  4 Delete  5 Exit")
    choice = input("Enter choice: ")
    if choice == "1":
        add_task()
    elif choice == "2":
        view_tasks()
    elif choice == "3":
        complete_task()
    elif choice == "4":
        delete_task()
    elif choice == "5":
        print("Goodbye.")
        break
    else:
        print("Invalid choice.")
