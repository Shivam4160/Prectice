import sqlite3

database = "university_assignment.db"
conn = sqlite3.connect(database)
cur = conn.cursor()

# Full dump: table definitions and data
with open("university_full_dump.sql", "w", encoding="utf-8") as f:
    for line in conn.iterdump():
        f.write(line + "\n")

# Schema-only dump
with open("university_schema_only.sql", "w", encoding="utf-8") as f:
    for row in cur.execute("""SELECT sql FROM sqlite_master
        WHERE type='table' AND sql IS NOT NULL"""):
        f.write(row[0] + ";\n")

# Data-only dump: INSERT statements for user tables
with open("university_data_only.sql", "w", encoding="utf-8") as f:
    tables = ["students", "courses", "enrollments"]
    for table in tables:
        for row in cur.execute("SELECT * FROM " + table):
            values = ", ".join(repr(value) for value in row)
            f.write("INSERT INTO " + table + " VALUES (" + values + ");\n")

print("Created full, schema-only and data-only SQL dump files.")
conn.close()
