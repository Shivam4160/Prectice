import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()
print("Connected to inventory.db and cursor created.")
conn.close()
