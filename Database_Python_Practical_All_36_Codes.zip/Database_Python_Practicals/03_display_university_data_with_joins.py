import sqlite3

conn = sqlite3.connect("university_assignment.db")
cur = conn.cursor()

print("\nSTUDENTS")
for row in cur.execute("SELECT * FROM students"):
    print(row)

print("\nCOURSES")
for row in cur.execute("SELECT * FROM courses"):
    print(row)

print("\nENROLLMENT DETAILS (JOIN)")
query = """SELECT students.name, courses.course_name, enrollments.grade
FROM enrollments
JOIN students ON enrollments.student_id = students.student_id
JOIN courses ON enrollments.course_id = courses.course_id"""
for row in cur.execute(query):
    print(row)

conn.close()
