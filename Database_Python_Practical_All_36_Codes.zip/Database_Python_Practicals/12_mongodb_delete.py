from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
students = client["university_db"]["students_data"]

result_one = students.delete_one({"email": "jay@example.com"})
print("One student deleted:", result_one.deleted_count)

result_many = students.delete_many({"major": "Chemistry"})
print("Students from Chemistry deleted:", result_many.deleted_count)

client.close()
