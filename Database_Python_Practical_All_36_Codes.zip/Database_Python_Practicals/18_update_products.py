import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()
cur.execute("UPDATE products SET quantity=?, price=? WHERE name=?",
            (120, 12.0, "Pen"))
print("Rows updated:", cur.rowcount)
conn.commit()
conn.close()
