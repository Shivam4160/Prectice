import sqlite3

conn = sqlite3.connect("todo_list.db")
cur = conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    completed INTEGER DEFAULT 0
)""")
conn.commit()
print("To-do database and tasks table created.")
conn.close()
