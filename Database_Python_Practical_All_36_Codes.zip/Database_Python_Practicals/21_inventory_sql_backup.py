import sqlite3

conn = sqlite3.connect("inventory.db")
with open("inventory_backup.sql", "w", encoding="utf-8") as f:
    for line in conn.iterdump():
        f.write(line + "\n")
print("SQL backup created: inventory_backup.sql")
conn.close()
