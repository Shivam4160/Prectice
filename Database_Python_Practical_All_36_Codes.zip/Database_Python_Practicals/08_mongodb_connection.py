from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError

try:
    client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=3000)
    client.admin.command("ping")
    db = client["university_db"]
    students = db["students_data"]
    print("MongoDB connected successfully.")
    print("Database:", db.name)
    print("Collection:", students.name)
    client.close()
except ServerSelectionTimeoutError:
    print("MongoDB is not running. Start the local MongoDB service and try again.")
