import tkinter as tk
from tkinter import messagebox
import sqlite3

DB = "college_students.db"
TABLE = "college_students"
FIELDS = ['name', 'roll_no', 'department', 'semester']
LABELS = ['Student Name', 'Roll Number', 'Department', 'Semester']

def setup():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS " + TABLE +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ", ".join(name + " TEXT" for name in FIELDS) + ")")
    conn.commit()
    conn.close()

def save_record():
    values = [entries[name].get().strip() for name in FIELDS]
    if not all(values):
        messagebox.showwarning("Required", "Please fill all fields.")
        return
    conn = sqlite3.connect(DB)
    marks = ", ".join(["?"] * len(FIELDS))
    names = ", ".join(FIELDS)
    conn.execute("INSERT INTO " + TABLE + " (" + names + ") VALUES (" + marks + ")", values)
    conn.commit()
    conn.close()
    messagebox.showinfo("Saved", "Record saved successfully.")
    clear_form()
    show_records()

def show_records():
    output.delete("1.0", tk.END)
    conn = sqlite3.connect(DB)
    rows = conn.execute("SELECT * FROM " + TABLE).fetchall()
    conn.close()
    for row in rows:
        output.insert(tk.END, str(row) + "\\n")

def search_record():
    record_id = id_entry.get().strip()
    if not record_id:
        messagebox.showwarning("Search", "Enter record ID.")
        return
    conn = sqlite3.connect(DB)
    row = conn.execute("SELECT * FROM " + TABLE + " WHERE id=?", (record_id,)).fetchone()
    conn.close()
    if row:
        for i, name in enumerate(FIELDS):
            entries[name].delete(0, tk.END)
            entries[name].insert(0, row[i + 1])
        messagebox.showinfo("Found", "Record found.")
    else:
        messagebox.showinfo("Not found", "No record with this ID.")

def update_record():
    record_id = id_entry.get().strip()
    if not record_id:
        messagebox.showwarning("Update", "Enter ID and search first.")
        return
    values = [entries[name].get().strip() for name in FIELDS]
    conn = sqlite3.connect(DB)
    sets = ", ".join(name + "=?" for name in FIELDS)
    cur = conn.execute("UPDATE " + TABLE + " SET " + sets + " WHERE id=?",
                       values + [record_id])
    conn.commit()
    conn.close()
    messagebox.showinfo("Update", "Rows updated: " + str(cur.rowcount))
    show_records()

def delete_record():
    record_id = id_entry.get().strip()
    if not record_id:
        messagebox.showwarning("Delete", "Enter record ID.")
        return
    conn = sqlite3.connect(DB)
    cur = conn.execute("DELETE FROM " + TABLE + " WHERE id=?", (record_id,))
    conn.commit()
    conn.close()
    messagebox.showinfo("Delete", "Rows deleted: " + str(cur.rowcount))
    clear_form()
    show_records()

def clear_form():
    id_entry.delete(0, tk.END)
    for entry in entries.values():
        entry.delete(0, tk.END)

setup()
root = tk.Tk()
root.title("College Student Registration")
root.geometry("650x520")
root.configure(bg="#eef3f8")
tk.Label(root, text="College Student Registration", font=("Arial", 18, "bold"),
         bg="#eef3f8").pack(pady=10)

form = tk.Frame(root, bg="#eef3f8")
form.pack()
tk.Label(form, text="Record ID", bg="#eef3f8").grid(row=0, column=0, sticky="w", pady=4)
id_entry = tk.Entry(form, width=32)
id_entry.grid(row=0, column=1, pady=4)
entries = {}
for i, name in enumerate(FIELDS):
    tk.Label(form, text=LABELS[i], bg="#eef3f8").grid(row=i+1, column=0, sticky="w", pady=4)
    entries[name] = tk.Entry(form, width=32)
    entries[name].grid(row=i+1, column=1, pady=4)

buttons = tk.Frame(root, bg="#eef3f8")
buttons.pack(pady=10)
for label, command in [("Save", save_record), ("Search", search_record),
                       ("Update", update_record), ("Delete", delete_record),
                       ("Display", show_records), ("Clear", clear_form)]:
    tk.Button(buttons, text=label, width=10, command=command).pack(side=tk.LEFT, padx=3)

tk.Label(root, text="Saved Records", bg="#eef3f8",
         font=("Arial", 12, "bold")).pack()
output = tk.Text(root, height=12, width=75)
output.pack(padx=10, pady=8)
show_records()
root.mainloop()
