from pymongo import MongoClient
from bson import json_util
import json

client = MongoClient("mongodb://localhost:27017/")
students = client["university_db"]["students_data"]

# Export Physics students to JSON Lines
with open("physics_students.jsonl", "w", encoding="utf-8") as f:
    for student in students.find({"major": "Physics"}):
        f.write(json_util.dumps(student) + "\n")
print("Physics students exported to JSON Lines.")

# Create a small JSON file for import practice
new_data = [
    {"roll_no": 201, "name": "Ravi Shah", "email": "ravi@example.com",
     "major": "Physics", "enrollments": []},
    {"roll_no": 202, "name": "Nita Patel", "email": "nita@example.com",
     "major": "Physics", "enrollments": []}
]
with open("new_students.json", "w", encoding="utf-8") as f:
    json.dump(new_data, f, indent=4)

try:
    with open("new_students.json", "r", encoding="utf-8") as f:
        imported = json.load(f)
    for student in imported:
        try:
            students.insert_one(student)
            print("Imported:", student["name"])
        except Exception as error:
            print("Skipped duplicate/error:", error)
except (OSError, json.JSONDecodeError) as error:
    print("File error:", error)

client.close()
