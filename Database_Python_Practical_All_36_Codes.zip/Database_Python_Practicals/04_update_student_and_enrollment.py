import sqlite3

conn = sqlite3.connect("university_assignment.db")
cur = conn.cursor()

cur.execute("UPDATE students SET major=? WHERE email=?",
            ("Computer Applications", "amit@example.com"))
cur.execute("""UPDATE enrollments SET grade=?
WHERE enrollment_id=(SELECT MIN(enrollment_id) FROM enrollments)""",
            ("A+",))

conn.commit()
print("Student and enrollment records updated.")
print("Student rows changed:", cur.rowcount)
conn.close()
