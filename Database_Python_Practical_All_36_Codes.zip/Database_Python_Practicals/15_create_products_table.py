import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL
)""")
conn.commit()
print("Products table created.")
conn.close()
