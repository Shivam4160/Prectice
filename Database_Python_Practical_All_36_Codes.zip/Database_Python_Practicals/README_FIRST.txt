DATABASE USING PYTHON — PRACTICAL CODE PACK
===========================================

This pack contains 36 simple, separate Python programs based on your 36 practice questions.
The examples follow the beginner-friendly style of your journal: sqlite3, pymongo, tkinter,
simple functions, SQL commands and basic MongoDB operations.

IMPORTANT SOFTWARE
------------------
1. Python 3
2. VS Code (recommended editor; IDLE also works)
3. SQLite: Python's sqlite3 module is included with normal Python installation.
4. MongoDB Community Server (local installation) for practicals 8–13 and 30–36.
5. PyMongo Python package for practicals 8–13 and 30–36.
6. Tkinter is normally included with Python on Windows.

CHECK SOFTWARE IN CMD
---------------------
python --version
py --version
python -c "import sqlite3; print(sqlite3.sqlite_version)"
python -m tkinter
python -m pip show pymongo
mongosh --version

INSTALL PYTHON PACKAGE
----------------------
python -m pip install pymongo

MongoDB must be installed and its local service must be running before MongoDB programs.
These programs connect to mongodb://localhost:27017/ and do not need internet after
the local server and package have been installed.

HOW TO RUN
----------
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal.
4. Run one file at a time:
   python 01_create_university_database.py
   python 02_insert_university_sample_data.py
   etc.
   On Windows, `py filename.py` can be used instead.
5. Run the SQLite programs in number order when they depend on a database/table created earlier.
6. Run MongoDB programs only after starting the MongoDB server.

QUESTION MAPPING
----------------
Q1-Q7   : University SQLite database, sample data, JOIN, update, delete, SQL dumps, CSV.
Q8-Q13  : MongoDB connection, insert, retrieval, update, delete, JSON.
Q14-Q22 : Inventory SQLite database and products table.
Q23-Q25 : To-do list SQLite application.
Q26-Q29 : Tkinter + SQLite registration applications.
Q30-Q36 : Tkinter + MongoDB management application examples.

DATABASE FILES
--------------
SQLite creates .db files in the current working folder when a program runs.
CSV, JSON, JSONL and SQL dump files are also created in that folder.

NOTES / LIMITATIONS
------------------
- Re-run Q2 safely: it uses INSERT OR IGNORE for student/course sample records and checks
  enrollment pairs, to avoid repeatedly inserting the same sample data.
- Q5 deletes the selected student's enrollment first, then the student, because of the
  foreign-key relationship.
- Q6 creates full, schema-only and data-only SQL files.
- Q13 creates a sample JSON file and imports it; duplicate insertion errors are reported.
- Q26-Q29 are simple demonstration forms with basic CRUD features.
- Q30, Q31, Q32, Q34 and Q36 include a Calculate button for the requested calculations.
  Q30 uses three subject marks; Q31 calculates gross and net salary; Q32 calculates amount,
  discount, GST at 18% and final bill; Q34 calculates attendance percentage; Q36 uses
  example room rates (General 1000, Semi-Private 2000, Private 3000 per day).
- Use sample practice data only. Do not store real passwords or sensitive personal data.

BEST PRACTICE
-------------
Run each program separately and check its output. Do not run all files together.
If you see "no such table", run the table-creation practical first.
If MongoDB shows connection refused, start the local MongoDB service.
If "No module named pymongo" appears, run: python -m pip install pymongo
