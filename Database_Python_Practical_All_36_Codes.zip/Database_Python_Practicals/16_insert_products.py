import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()

cur.execute("INSERT INTO products(name, quantity, price) VALUES (?, ?, ?)",
            ("Pen", 100, 10.5))
print("Single product inserted. Last ID:", cur.lastrowid)

items = [("Notebook", 50, 45), ("Pencil", 80, 5), ("Bag", 20, 550)]
cur.executemany("INSERT INTO products(name, quantity, price) VALUES (?, ?, ?)", items)
print("Multiple products inserted. Rows affected:", cur.rowcount)

conn.commit()
conn.close()
