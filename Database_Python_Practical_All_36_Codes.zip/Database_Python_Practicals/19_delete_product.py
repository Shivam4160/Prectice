import sqlite3

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()
cur.execute("DELETE FROM products WHERE id=?", (1,))
print("Rows deleted:", cur.rowcount)
conn.commit()
conn.close()
