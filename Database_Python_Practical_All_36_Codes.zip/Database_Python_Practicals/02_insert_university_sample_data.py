import sqlite3

conn = sqlite3.connect("university_assignment.db")
cur = conn.cursor()
cur.execute("PRAGMA foreign_keys = ON")

students = [
    ("Amit Sharma", 20, "Computer Science", "amit@example.com"),
    ("Priya Patel", 21, "Information Technology", "priya@example.com"),
    ("Rahul Verma", 22, "Electronics", "rahul@example.com"),
    ("Sneha Joshi", 20, "Computer Science", "sneha@example.com")
]
courses = [
    ("CS101", "Database Systems", 4),
    ("CS102", "Python Programming", 3),
    ("IT201", "Cloud Computing", 4)
]

cur.executemany("""INSERT OR IGNORE INTO students
(name, age, major, email) VALUES (?, ?, ?, ?)""", students)
cur.executemany("""INSERT OR IGNORE INTO courses
(course_code, course_name, credits) VALUES (?, ?, ?)""", courses)

cur.execute("SELECT student_id FROM students WHERE email='amit@example.com'")
amit = cur.fetchone()[0]
cur.execute("SELECT student_id FROM students WHERE email='priya@example.com'")
priya = cur.fetchone()[0]
cur.execute("SELECT course_id FROM courses WHERE course_code='CS101'")
db_course = cur.fetchone()[0]
cur.execute("SELECT course_id FROM courses WHERE course_code='CS102'")
python_course = cur.fetchone()[0]

enrollments = [(amit, db_course, "A"), (amit, python_course, "A+"),
               (priya, db_course, "B+")]
cur.executemany("""INSERT INTO enrollments(student_id, course_id, grade)
SELECT ?, ?, ? WHERE NOT EXISTS
(SELECT 1 FROM enrollments WHERE student_id=? AND course_id=?)""",
                [(s, c, g, s, c) for s, c, g in enrollments])

conn.commit()
print("Sample students, courses and enrollments inserted.")
conn.close()
