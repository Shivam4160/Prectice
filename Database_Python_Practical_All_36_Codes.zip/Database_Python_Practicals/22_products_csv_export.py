import sqlite3
import csv

conn = sqlite3.connect("inventory.db")
cur = conn.cursor()
cur.execute("SELECT * FROM products")
rows = cur.fetchall()

with open("products_export.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["id", "name", "quantity", "price"])
    writer.writerows(rows)

print("Products exported to products_export.csv")
conn.close()
